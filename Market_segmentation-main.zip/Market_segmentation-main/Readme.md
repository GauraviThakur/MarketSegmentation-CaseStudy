**Market Segmentation**
